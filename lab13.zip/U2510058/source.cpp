#include <iostream>
#include "header.h"
using namespace std;

int main() {

    studentAccount students;
    students.setaccountNumber("888");
    students.setStudentName("Behruz");
    students.setUniversityID("U2510058");
    students.setBalance(1000000);
    students.setWithdraw(560000);

    studentAccount studentr;
    studentr.setaccountNumber("999");
    studentr.setStudentName("Xondamir");
    studentr.setUniversityID("U2510055");
    studentr.setBalance(800000);
    studentr.setWithdraw(500000);

    cout << "Student Account 1:";
    students.display();

    cout << "\nStudent Account 2:";
    studentr.display();

    return 0;
}
