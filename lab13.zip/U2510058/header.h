#include<iostream>
using namespace std;
class studentAccount {
  private: 
    string accountNumber;
    string studentName;
    string universityID;
    double balance;
    double withdraw;
  public:
    void setaccountNumber(string number) {
      accountNumber = number;
    }

    void setStudentName(string name) {
      studentName = name;
    }

    void setUniversityID(string id) {
      universityID = id;
    }

    void setBalance(double bal) {
      balance = bal;
    }

    void setWithdraw(double money) {
      withdraw = money;
      balance -= money;
    }

    string getAccountNumber() {
      return accountNumber;
    }

    string getStudentName() {
      return studentName;
    }

    string getUniversityID() {
      return universityID;
    }

    double getBalance() {
      return balance;
    }

    double getWithdraw() {
      return withdraw;
    }

    void display() {
        cout << "\nAccount Number: " << accountNumber << endl;
        cout << "Student Name: " << studentName << endl;
        cout << "University ID: " << universityID << endl;
        cout << "Balance: " << balance << endl;
        cout << "Withdrawn: " << withdraw << endl;
    }
    
};
      


