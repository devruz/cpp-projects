#include <iostream>
using namespace std;
class StockEx { 
  private: 
    string currency;
    float mktrate;
    string date;
  public:
    StockEx(){
      currency = "Unknown";
      mktrate = 0.0;
      date = "00.00.0000";
    };
    StockEx(string currency, float mktrate, string date){
      this->currency = currency;
      this->mktrate = mktrate;
      this->date = date;
    }; 
    string getCurrency() const {
      return currency;
    }
    float getMarketRate() const {
      return mktrate;
    }
    string getDate() const {
      return date;
    }
    float operator*(float amount) const{
      return amount * mktrate;
    }
    float operator-(const StockEx& other){
      return mktrate - other.mktrate;
    }
    bool operator>(const StockEx& other) const {
      return mktrate > other.mktrate;
    }
    friend istream& operator>>(istream& in, StockEx& obj) {
      cout << "Enter currency: ";
      in >> obj.currency;
      cout << "Enter market rate: ";
      in >> obj.mktrate;
      cout << "Enter date: ";
      in >> obj.date;
      return in;
    }
    friend ostream& operator<<(ostream& out, const StockEx& obj) {
      out << "Currency: " << obj.currency << endl;
      out << "Market rate: " << obj.currency << endl;
      out << "Date: " << obj.date << endl;
      return out;
    }  
};