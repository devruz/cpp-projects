#include "header.h"
int main() {
    StockEx market1, market2;
    cout << "Enter details for first market:" << endl;
    cin >> market1;
    cout << "Enter details for second market:" << endl;
    cin >> market2;
    cout << endl << "First Market:" << endl;
    cout << market1 << endl;
    cout << "Second Market:" << endl;
    cout << market2 << endl;

    int choice;
    float amount;

    cout << "Choose market for currency exchange:" << endl;
    cout << "1. First Market" << endl;
    cout << "2. Second Market" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    cout << "Enter amount to exchange: ";
    cin >> amount;

    if (choice == 1) {
        cout << "Converted amount: " << market1 * amount << endl;
    } else if (choice == 2) {
        cout << "Converted amount: " << market2 * amount << endl;
    } else {
        cout << "Invalid choice!" << endl;
    }

    cout << endl;
    cout << "Difference between market rates: " << market1 - market2 << endl;

    if (market1 > market2) {
        cout << "First market rate is higher." << endl;
    } else if (market2 > market1) {
        cout << "Second market rate is higher." << endl;
    } else {
        cout << "Both market rates are equal." << endl;
    }

    return 0;    
}