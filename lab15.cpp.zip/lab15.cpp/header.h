#include <iostream>
#include <string>
using namespace std;

class Account {
  private:
    int bankCard;
    string accountName;
    int pinNumber;
    static int accountCount;
  public:
  Account() {
    bankCard = 1;
    accountName = "unknown";
    pinNumber = 1000;
    accountCount++;
  }
  Account(int card, string name, int pin) {
    if (card > 0){
      card = bankCard;
    }
    else {
      bankCard = 1;
    }
    accountName = name;

    if (pin >= 1000 && pin <= 9999) {
      pinNumber = pin;
    }
    else {
      pinNumber = 1000;
    }
    accountCount++;
  }
  ~Account() {
    accountCount--;
  }
  void display() const{
    cout << "Bank card: " << bankCard << endl;
    cout << "Account name: " << accountName << endl;
    cout << "Pin number: " << pinNumber << endl;
  }
  static int getAccountCount() {
    return accountCount;
  };
};

int Account::accountCount = 0;

class Balance {
  private:
    double balance;
    static int balanceObjects;
  public:
  Balance() {
    balance = 0.0;
    balanceObjects++;
  }
  Balance(double bal) {
    if (bal > 0) {
      balance = bal;
    }
    else {
      balance = 0;
    }
    balanceObjects++;
  }
  ~Balance() {
    balanceObjects--;
  }
  void deposit(double amount){
    if(amount > 0) {
      balance += amount;
    }
    else {
      cout << "Invalid amount!!!\n";
    }
  }
  bool withdraw(double amount) {
    if(amount > 0 && amount <= balance) {
      return true;
    }
    else {
      return false;
    }
  }
  void showBalance() const {
    cout << "Balance: " <<endl;
    cout << "Your current balance: " << balance << endl;
  }
  static int getBlanceObjectCount(){
    return balanceObjects;
  };
};
int Balance::balanceObjects = 0;
class ATM {
  private:
  Account account;
  Balance balance;
  static int atmCount;
  public:
  ATM() : account(), balance() {
    atmCount++;
  };
  ATM(int card, string name, int pin, double bal)
  : account(card, name, pin), balance(bal){
    atmCount++;
  }
  void print() const {
    account.display();
    balance.showBalance();
  }
  void deposit(double amount) {
    balance.deposit(amount);
  }
  void withdraw(double amount) {
    balance.withdraw(amount);
  }
  static int getATMCount(){
    return atmCount;
  }
};
int ATM::atmCount = 0;