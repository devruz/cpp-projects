#include "header.h"
int main() {
  int n;
  cout << "Enter number of ATM users: ";
  cin >> n;
  ATM* users = new ATM[n]{
    ATM(0, "Default", 1000, 0.0)
  };
  for(int i = 0; i < n; i++) {
    int card, pin;
    string name;
    double bal;
    cout << "Enter info for user " << i + 1 << ": " << endl;
    cout << "Card number: ";
    cin >> card;
    cin.ignore();
    cout << "\nAccount name: ";
    getline(cin, name);
    cout << "PIN: ";
    cin >> pin;
    cout << "Initial balance: ";
    cin >> bal;  
    users[i] = ATM(card, name, pin, bal);
  }
  cout << "BEFORE TRANSACTIONS" << endl;
  for(int i = 0; i < n; i++){
    cout << "User " << i + 1 << endl;
    users[i].print();
  }
  int index;
  double amount;
  cout << "Enter user index for deposit (1.." << n << "): ";
  cin >> index;

  if (index >= 1 && index <= n) {
    cout << "Enter deposit amount: ";
    cin >> amount;
    users[index - 1].deposit(amount);
  }
  else {
    cout << "Invalid user index.\n";
  }
  cout << "\nEnter user index for withdrawal (1..." << n << "): ";
    cin >> index;

    if (index >= 1 && index <= n) {
        cout << "Enter withdrawal amount: ";
        cin >> amount;
        users[index - 1].withdraw(amount);
    } else {
        cout << "Invalid user index.\n";
    }

    cout << "\nAFTER TRANSACTIONS\n";
    for (int i = 0; i < n; i++) {
        cout << "\nUser " << i + 1 << ":\n";
        users[i].print();
    }

    cout << "\nSTATIC COUNTERS\n";
    cout << "Total Account objects: " << Account::getAccountCount() << endl;
    cout << "Total Balance objects: " << Balance::getBlanceObjectCount << endl;
    cout << "Total ATM objects    : " << ATM::getATMCount() << endl;
    delete[] users;

    return 0;

}